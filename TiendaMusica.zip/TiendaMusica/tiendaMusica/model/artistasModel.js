import mongoose, { Schema } from "mongoose";

const ArtistasSchema = new Schema({
    
    nombreArtista: String, 
    genero: String,
    pais: String
})
export const ArtistasModel = new mongoose.model('Artistas', ArtistasSchema)
