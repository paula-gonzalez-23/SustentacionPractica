import mongoose, { Schema } from "mongoose";

const AlbumesSchema = new Schema({
    
    nombreCancion: String, 
    nombreArtista: String,
    año: Number
})
export const AlbumesModel = new mongoose.model('Albumes', AlbumesSchema)