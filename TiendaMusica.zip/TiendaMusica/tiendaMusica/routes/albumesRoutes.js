import express from 'express';
import { getAllAlbumes, updateAlbumYear, deleteAlbum } from '../controller/albumesController.js';

const router = express.Router();

// Ruta para consultar todos los álbumes
router.get('/albumes', getAllAlbumes);

// Ruta para actualizar el año de un álbum
router.put('/albumes/:nombre', updateAlbumYear);

// Ruta para eliminar un álbum
router.delete('/albumes/:nombre', deleteAlbum);

export default router;