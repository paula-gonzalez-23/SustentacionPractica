import { AlbumesModel } from '../model/albumesModel.js';

// Consultar todos los álbumes
export const getAllAlbumes = async (req, res) => {
    try {
    const albumes = await AlbumesModel.find();
    res.json(albumes);
    } catch (error) {
    res.status(500).json({ message: error.message });
    }
};

// Actualizar el año de un álbum específico
export const updateAlbumYear = async (req, res) => {
    try {
    const { nombre } = req.params;
    const { nuevoAño } = req.body;

    const album = await AlbumesModel.findOneAndUpdate(
    { nombreCancion: nombre },
    { año: nuevoAño },
    { new: true }

)};

// Eliminar un álbum
export const deleteAlbum = async (req, res) => {
    try {
    const { nombre } = req.params;

    const album = await AlbumesModel.findOneAndDelete({ nombreCancion: nombre });

    }
};